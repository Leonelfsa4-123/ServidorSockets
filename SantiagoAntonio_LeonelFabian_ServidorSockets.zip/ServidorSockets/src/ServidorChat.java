import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Servidor de mensajería privada por consola (sockets TCP).
 *
 * Protocolo (el mismo que usa ClienteChat):
 *   1) Primera línea enviada por el cliente al conectarse: su nombre de usuario.
 *   2) Mensaje privado: "@destinatario mensaje"
 *   3) Salir: "/salir"
 *
 * Funcionamiento:
 *   - El hilo principal solo acepta conexiones (accept) y por cada cliente crea
 *     un hilo propio. Así un cliente lento o bloqueado no afecta a los demás.
 *   - Un mapa "usuarios" guarda, por cada usuario conectado, el flujo de salida
 *     hacia su socket. Con ese mapa se sabe quién está conectado y a dónde
 *     reenviar cada mensaje.
 *   - Si un cliente se va (con /salir o cerrando de golpe), su hilo lo retira del
 *     mapa y el servidor sigue atendiendo a los demás.
 *
 * Puerto por defecto: 5000. Se puede cambiar: java -cp src ServidorChat 6000
 *
 * Solo se usan librerías estándar: java.io, java.net y java.util.
 */
public class ServidorChat {

    // ---------- Constantes ----------
    private static final int PUERTO_POR_DEFECTO = 5000;
    private static final String COMANDO_SALIR = "/salir";
    private static final String CODIFICACION = "UTF-8"; // acentos, ñ, ¿, ¡

    // ---------- Lista de usuarios conectados ----------
    // nombre de usuario -> flujo de salida hacia su cliente.
    // Varios hilos lo usan a la vez, así que TODO acceso se hace dentro de
    // synchronized (usuarios) para evitar conflictos.
    private static final Map<String, PrintWriter> usuarios = new HashMap<>();

    // ------------------------------------------------------------------
    //  Programa principal: aceptar conexiones
    // ------------------------------------------------------------------

    public static void main(String[] args) {
        int puerto = PUERTO_POR_DEFECTO;
        if (args.length >= 1) {
            try {
                puerto = Integer.parseInt(args[0]);
                if (puerto < 1 || puerto > 65535) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.out.println("[X] Puerto invalido: " + args[0] + " (debe ser un numero entre 1 y 65535).");
                return;
            }
        }

        // try-with-resources: el ServerSocket se cierra solo al terminar
        try (ServerSocket servidor = new ServerSocket(puerto)) {
            System.out.println("Servidor escuchando en el puerto " + puerto + "...");

            while (true) {
                try {
                    // accept() espera (se bloquea) hasta que un cliente se conecta
                    Socket cliente = servidor.accept();
                    System.out.println("Conexion entrante desde " + cliente.getInetAddress().getHostAddress());

                    // Un hilo por cliente: el hilo principal queda libre para aceptar al siguiente
                    Thread hilo = new Thread(() -> atenderCliente(cliente));
                    hilo.start();
                } catch (IOException e) {
                    // Un fallo al aceptar a UN cliente no debe detener el servidor
                    System.out.println("[!] Error al aceptar una conexion: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("[X] No se pudo iniciar el servidor en el puerto " + puerto + ": " + e.getMessage());
            System.out.println("    ¿Ya hay otro servidor usando ese puerto?");
        }
    }

    // ------------------------------------------------------------------
    //  Atención de un cliente (se ejecuta en un hilo por cliente)
    // ------------------------------------------------------------------

    static void atenderCliente(Socket cliente) {
        String nombre = null;
        boolean registrado = false; // true solo si este hilo logró guardar el nombre en el mapa

        try {
            // Flujos: entrada para leer línea por línea, salida con autoflush para enviar al instante
            BufferedReader entrada = new BufferedReader(new InputStreamReader(cliente.getInputStream(), CODIFICACION));
            PrintWriter salida = new PrintWriter(new OutputStreamWriter(cliente.getOutputStream(), CODIFICACION), true);

            // 1) Primera línea = nombre de usuario
            String solicitado = entrada.readLine();
            if (solicitado == null) {
                return; // el cliente se fue antes de identificarse
            }
            solicitado = solicitado.trim();

            String error = registrarUsuario(solicitado, salida);
            if (error != null) {
                salida.println(error);
                System.out.println("Conexion rechazada (" + solicitado + "): " + error);
                return; // el finally cierra el socket; NO se toca al usuario que ya existía
            }
            nombre = solicitado;
            registrado = true;

            System.out.println(nombre + " se conecto. Usuarios conectados: " + listaUsuarios());
            salida.println("Bienvenido, " + nombre + ". Usuarios conectados: " + listaUsuarios());
            salida.println("Usa @usuario mensaje para escribir a alguien, o /salir para terminar.");

            // 2) Ciclo principal: leer mensajes hasta que el cliente se vaya
            String linea;
            while ((linea = entrada.readLine()) != null) {
                linea = linea.trim();
                if (linea.isEmpty()) {
                    continue;
                }
                // "salir" sin diagonal se acepta por compatibilidad con la practica anterior
                if (linea.equalsIgnoreCase(COMANDO_SALIR) || linea.equalsIgnoreCase("salir")) {
                    System.out.println(nombre + " salio con " + COMANDO_SALIR);
                    return;
                }
                procesarMensaje(nombre, linea, salida);
            }
            // readLine() devolvió null: el cliente cerró la conexión sin escribir /salir
            System.out.println(nombre + " cerro la conexion sin avisar.");

        } catch (IOException e) {
            // Cierre inesperado (por ejemplo, el cliente se cerró a la fuerza)
            System.out.println("Conexion perdida con " + (nombre != null ? nombre : "un cliente") + ": " + e.getMessage());
        } finally {
            // Pase lo que pase, se limpia: el servidor SIGUE funcionando para los demás
            if (registrado) {
                synchronized (usuarios) {
                    usuarios.remove(nombre);
                }
                System.out.println(nombre + " se desconecto. Usuarios conectados: " + listaUsuarios());
            }
            try {
                cliente.close();
            } catch (IOException e) {
                // nada más que hacer
            }
        }
    }

    // ------------------------------------------------------------------
    //  Registro de usuarios
    // ------------------------------------------------------------------

    /**
     * Intenta registrar el nombre. Devuelve null si todo salió bien, o el texto
     * del error si el nombre no es válido o ya está en uso.
     * La comprobación y el put van juntos dentro de synchronized para que dos
     * clientes no puedan quedarse con el mismo nombre a la vez.
     */
    private static String registrarUsuario(String nombre, PrintWriter salida) {
        if (nombre.isEmpty()) {
            return "Error: el nombre de usuario no puede estar vacio. Cerrando conexion";
        }
        if (nombre.contains(" ") || nombre.startsWith("@") || nombre.startsWith("/")) {
            return "Error: el nombre no puede tener espacios ni empezar con @ o /. Cerrando conexion";
        }
        synchronized (usuarios) {
            if (usuarios.containsKey(nombre)) {
                return "Error: el nombre '" + nombre + "' ya esta en uso. Cerrando conexion";
            }
            usuarios.put(nombre, salida);
        }
        return null;
    }

    /** Devuelve los nombres de los usuarios conectados, ordenados, como texto. */
    private static String listaUsuarios() {
        synchronized (usuarios) {
            return new TreeSet<>(usuarios.keySet()).toString();
        }
    }

    // ------------------------------------------------------------------
    //  Mensajes privados
    // ------------------------------------------------------------------

    /**
     * Procesa una línea con formato "@destinatario mensaje" y la reenvía SOLO al
     * destinatario, anteponiendo el nombre del remitente. Si algo falla, avisa
     * al remitente.
     */
    static void procesarMensaje(String remitente, String linea, PrintWriter salidaRemitente) {
        // Formato: debe empezar con @ y tener destinatario y mensaje separados por un espacio
        int espacio = linea.indexOf(' ');
        if (!linea.startsWith("@") || espacio <= 1 || linea.substring(espacio + 1).trim().isEmpty()) {
            salidaRemitente.println("Formato invalido. Usa: @usuario mensaje");
            return;
        }

        String destinatario = linea.substring(1, espacio);
        String mensaje = linea.substring(espacio + 1).trim();

        // Buscar al destinatario en la lista de conectados
        PrintWriter salidaDestino;
        synchronized (usuarios) {
            salidaDestino = usuarios.get(destinatario);
        }

        if (salidaDestino == null) {
            // El usuario no existe o ya se desconectó: se informa al remitente
            salidaRemitente.println("El usuario '" + destinatario + "' no existe o no esta conectado.");
            System.out.println(remitente + " -> " + destinatario + ": (destinatario no encontrado)");
            return;
        }

        // Entrega: solo al destinatario, con el nombre del remitente por delante
        salidaDestino.println(remitente + " (privado): " + mensaje);

        // PrintWriter no lanza excepciones: checkError() indica si la escritura falló
        if (salidaDestino.checkError()) {
            salidaRemitente.println("No se pudo entregar el mensaje a '" + destinatario + "'.");
            System.out.println(remitente + " -> " + destinatario + ": (fallo de entrega)");
            return;
        }
        System.out.println(remitente + " -> " + destinatario + ": " + mensaje);
    }
}
