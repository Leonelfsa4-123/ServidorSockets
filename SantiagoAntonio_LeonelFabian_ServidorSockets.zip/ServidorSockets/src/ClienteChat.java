import java.io.*;
import java.net.*;
import java.util.Scanner;

/**
 * Cliente de mensajería privada por consola (sockets TCP).
 *
 * Protocolo (el mismo que usa ServidorChat):
 *   1) Primera línea enviada al conectarse: el nombre de usuario.
 *   2) Mensaje privado: "@destinatario mensaje"
 *   3) Salir: "/salir"
 *
 * Hilos:
 *   - Hilo principal: lee del teclado y envía al servidor.
 *   - Hilo receptor : lee del servidor y muestra los mensajes en cualquier
 *                     momento, aunque el usuario esté escribiendo.
 *
 * Solo se usan librerías estándar: java.io, java.net y java.util.
 */
public class ClienteChat {

    // ---------- Constantes de configuración ----------
    private static final String HOST_POR_DEFECTO = "localhost";
    private static final int PUERTO_POR_DEFECTO = 5000;
    private static final int TIEMPO_MAX_CONEXION_MS = 5000; // espera máxima al conectar
    private static final String COMANDO_SALIR = "/salir";
    private static final String CODIFICACION = "UTF-8";     // acentos, ñ, ¿, ¡

    // ---------- Estado compartido entre los dos hilos ----------
    // volatile: el valor escrito por un hilo es visible de inmediato para el otro.
    private static volatile boolean activo = true;

    private static Socket socket;
    private static BufferedReader entrada;   // lo que llega del servidor
    private static PrintWriter salida;       // lo que enviamos al servidor
    private static Scanner teclado;

    public static void main(String[] args) {
        teclado = new Scanner(System.in);
        try {
            iniciar(args);
        } finally {
            // Cierre ordenado pase lo que pase: socket, flujos y teclado.
            // El teclado se cierra aquí (hilo principal) y NO en el hilo receptor:
            // cerrar System.in mientras otro hilo espera en nextLine() deja el programa colgado.
            activo = false;
            cerrarRecursos();
            teclado.close();
        }
    }

    /** Flujo completo del programa: datos de conexión, identificación y chat. */
    private static void iniciar(String[] args) {
        mostrarInstrucciones();

        // 1) Datos de conexión: por argumentos (java ClienteChat <ip> <puerto>)
        //    o, si no se dan, preguntándolos con valores por defecto.
        String host;
        int puerto;
        if (args.length >= 1) {
            host = args[0];
            puerto = (args.length >= 2) ? convertirPuerto(args[1]) : PUERTO_POR_DEFECTO;
            if (puerto == -1) {
                System.out.println("[X] Puerto invalido en los argumentos: " + args[1]);
                return;
            }
        } else {
            host = pedirHost();
            puerto = pedirPuerto();
        }

        // 2) Conexión con el servidor
        if (!conectar(host, puerto)) {
            return; // el mensaje de error ya se mostró dentro de conectar()
        }

        // 3) Identificación: el nombre de usuario es la PRIMERA línea que se envía
        String nombre = pedirNombre();
        if (nombre == null) { // el usuario cerró la entrada (Ctrl+D / Ctrl+Z)
            return;
        }
        salida.println(nombre);
        System.out.println("Sesión iniciada como '" + nombre + "'. Ya puedes escribir.\n");

        // 4) Hilo receptor: imprime lo que llegue del servidor en tiempo real
        Thread receptor = new Thread(ClienteChat::recibirMensajes, "hilo-receptor");
        receptor.setDaemon(true); // no impide que el programa termine
        receptor.start();

        // 5) Hilo principal: leer teclado y enviar
        enviarMensajes();

        System.out.println("Desconectado. ¡Hasta luego!");
    }

    // ------------------------------------------------------------------
    //  Interfaz de usuario
    // ------------------------------------------------------------------

    /** Muestra las instrucciones de uso al iniciar el programa. */
    private static void mostrarInstrucciones() {
        System.out.println("==========================================");
        System.out.println("      CLIENTE DE MENSAJERÍA PRIVADA");
        System.out.println("==========================================");
        System.out.println("Instrucciones:");
        System.out.println("  - Enviar mensaje privado :  @destinatario mensaje");
        System.out.println("                              ej.  @ana hola, ¿ya terminaste?");
        System.out.println("  - Salir                  :  /salir");
        System.out.println("  - Los mensajes que te escriban aparecerán solos en pantalla.");
        System.out.println("  - Para conectarte a otro equipo: java ClienteChat <ip> <puerto>");
        System.out.println("    (o presiona Enter para usar los valores por defecto).");
        System.out.println("------------------------------------------\n");
    }

    /** Pide la IP o nombre del servidor; Enter = localhost. */
    private static String pedirHost() {
        System.out.print("IP del servidor [" + HOST_POR_DEFECTO + "]: ");
        String texto = leerLinea();
        if (texto == null || texto.trim().isEmpty()) {
            return HOST_POR_DEFECTO;
        }
        return texto.trim();
    }

    /** Pide el puerto hasta que sea válido; Enter = 5000. */
    private static int pedirPuerto() {
        while (true) {
            System.out.print("Puerto [" + PUERTO_POR_DEFECTO + "]: ");
            String texto = leerLinea();
            if (texto == null || texto.trim().isEmpty()) {
                return PUERTO_POR_DEFECTO;
            }
            int puerto = convertirPuerto(texto.trim());
            if (puerto != -1) {
                return puerto;
            }
            System.out.println("[!] Puerto invalido. Debe ser un numero entre 1 y 65535.");
        }
    }

    /** Pide el nombre de usuario (obligatorio y sin espacios). Devuelve null si se cierra la entrada. */
    private static String pedirNombre() {
        while (true) {
            System.out.print("Escribe tu nombre de usuario: ");
            String nombre = leerLinea();
            if (nombre == null) {
                return null;
            }
            nombre = nombre.trim();
            if (nombre.isEmpty()) {
                System.out.println("[!] El nombre no puede estar vacio.");
            } else if (nombre.contains(" ") || nombre.startsWith("@") || nombre.startsWith("/")) {
                // Sin espacios porque "@destinatario mensaje" se separa por el primer espacio
                System.out.println("[!] El nombre no puede tener espacios ni empezar con @ o /.");
            } else {
                return nombre;
            }
        }
    }

    /** Lee una línea del teclado; devuelve null si ya no hay más entrada. */
    private static String leerLinea() {
        return teclado.hasNextLine() ? teclado.nextLine() : null;
    }

    /** Convierte texto a puerto. Devuelve -1 si no es un número entre 1 y 65535. */
    private static int convertirPuerto(String texto) {
        try {
            int puerto = Integer.parseInt(texto);
            return (puerto >= 1 && puerto <= 65535) ? puerto : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // ------------------------------------------------------------------
    //  Conexión
    // ------------------------------------------------------------------

    /**
     * Abre el socket y los flujos de entrada/salida.
     * Si algo falla, muestra un mensaje claro y devuelve false.
     */
    private static boolean conectar(String host, int puerto) {
        System.out.println("Conectando a " + host + ":" + puerto + " ...");
        try {
            socket = new Socket();
            // connect con tiempo máximo: así no se queda colgado si el servidor no responde
            socket.connect(new InetSocketAddress(host, puerto), TIEMPO_MAX_CONEXION_MS);

            // InputStreamReader convierte bytes en texto; BufferedReader permite leer línea por línea
            entrada = new BufferedReader(new InputStreamReader(socket.getInputStream(), CODIFICACION));
            // PrintWriter con autoflush=true envía cada println inmediatamente
            salida = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), CODIFICACION), true);

            System.out.println("[OK] Conectado al servidor en " + host + ":" + puerto + "\n");
            return true;

        } catch (UnknownHostException e) {
            System.out.println("[X] No se encontró el servidor '" + host + "'. Revisa la dirección IP.");
        } catch (SocketTimeoutException e) {
            System.out.println("[X] El servidor no respondió a tiempo (" + (TIEMPO_MAX_CONEXION_MS / 1000)
                    + " s). Revisa la IP, el puerto y el firewall.");
        } catch (ConnectException e) {
            System.out.println("[X] Servidor no disponible en " + host + ":" + puerto
                    + ". ¿Está encendido el servidor y es el puerto correcto?");
        } catch (IOException e) {
            System.out.println("[X] No se pudo conectar: " + e.getMessage());
        }
        cerrarRecursos();
        return false;
    }

    // ------------------------------------------------------------------
    //  Hilo principal: envío de mensajes
    // ------------------------------------------------------------------

    /** Lee lo que escribe el usuario y lo manda al servidor hasta que escriba /salir. */
    private static void enviarMensajes() {
        while (activo) {
            String texto = leerLinea();

            if (texto == null) {               // Ctrl+D / Ctrl+Z: se trata como /salir
                enviarSalir();
                return;
            }
            texto = texto.trim();
            if (texto.isEmpty()) {
                continue;
            }

            if (texto.equalsIgnoreCase(COMANDO_SALIR)) {
                enviarSalir();
                return;
            }

            // Validamos el formato antes de enviar: "@destinatario mensaje"
            if (!formatoValido(texto)) {
                System.out.println("[!] Formato invalido. Usa: @destinatario mensaje   (o /salir para terminar)");
                continue;
            }

            salida.println(texto);
            // PrintWriter no lanza excepciones: hay que preguntar si hubo error al escribir
            if (salida.checkError()) {
                if (activo) {
                    System.out.println("[X] No se pudo enviar el mensaje: se perdió la conexión con el servidor.");
                }
                activo = false;
                return;
            }

            // Eco local para ver qué se envió y a quién
            int espacio = texto.indexOf(' ');
            System.out.println("[Tú -> " + texto.substring(1, espacio) + "] " + texto.substring(espacio + 1).trim());
        }
    }

    /** Un mensaje válido empieza con @, tiene destinatario y tiene texto después del primer espacio. */
    private static boolean formatoValido(String texto) {
        if (!texto.startsWith("@")) {
            return false;
        }
        int espacio = texto.indexOf(' ');
        return espacio > 1 && !texto.substring(espacio + 1).trim().isEmpty();
    }

    /** Avisa al servidor que nos vamos y marca el fin de la sesión. */
    private static void enviarSalir() {
        activo = false;                // a partir de aquí, el receptor no reporta errores
        salida.println(COMANDO_SALIR);
    }

    // ------------------------------------------------------------------
    //  Hilo receptor
    // ------------------------------------------------------------------

    /**
     * Se ejecuta en un hilo aparte. readLine() se bloquea esperando datos,
     * por eso necesita su propio hilo: así los mensajes se muestran en el
     * momento en que llegan, sin importar si el usuario está escribiendo.
     */
    private static void recibirMensajes() {
        try {
            String linea;
            while ((linea = entrada.readLine()) != null) {
                System.out.println(linea);
            }
            // readLine devolvió null: el servidor cerró la conexión
            if (activo) {
                System.out.println("\n[X] El servidor cerró la conexión.");
            }
        } catch (IOException e) {
            // Si el usuario salió voluntariamente, el cierre del socket provoca esta excepción: es normal
            if (activo) {
                System.out.println("\n[X] Se perdió la conexión con el servidor (" + e.getMessage() + ").");
            }
        } finally {
            if (activo) {
                // Conexión perdida sin que el usuario lo pidiera: cerramos todo y terminamos el programa
                // (el hilo principal está bloqueado esperando el teclado y no se puede interrumpir).
                activo = false;
                cerrarRecursos();
                System.out.println("Desconectado. Vuelve a ejecutar el cliente para reconectarte.");
                System.exit(1);
            }
        }
    }

    // ------------------------------------------------------------------
    //  Cierre de recursos
    // ------------------------------------------------------------------

    /**
     * Cierra socket y flujos (el teclado lo cierra main). El socket se cierra PRIMERO para desbloquear
     * al hilo receptor que podría estar esperando en readLine().
     */
    private static void cerrarRecursos() {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException e) {
            // nada más que hacer
        }
        try {
            if (entrada != null) {
                entrada.close();
            }
        } catch (IOException e) {
            // nada más que hacer
        }
        if (salida != null) {
            salida.close(); // PrintWriter.close() no lanza excepciones
        }
    }
}
