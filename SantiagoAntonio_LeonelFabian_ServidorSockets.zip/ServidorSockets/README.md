# Servidor de mensajería privada con sockets (Java)

Práctica IFF-1019. Servidor por consola que atiende a varios clientes al mismo tiempo
(un hilo por cliente) y reenvía cada mensaje únicamente al destinatario elegido por el remitente.

- **Lenguaje:** Java (solo librerías estándar: `java.io`, `java.net` y `java.util`)
- **Interacción:** Por consola
- **Puerto utilizado:** **5000** (por defecto; se puede cambiar, ver más abajo)
- **Autor:** Leonel Fabian Santiago Antonio

## Estructura del proyecto

```
ServidorSockets/
├── src/
│   ├── ServidorChat.java   <- ENTREGABLE: el servidor
│   └── ClienteChat.java    <- cliente de la práctica anterior, solo para probar el servidor
├── capturas/               <- capturas de la prueba de funcionamiento
│   └── logs/               <- salida en texto de cada terminal
├── README.md
```

## Requisitos

- JDK 8 o superior (probado con JDK 21).
- Comprobar que está instalado: `javac -version` y `java -version`.

## Compilar y ejecutar el servidor

> **Importante:** los comandos se escriben desde la carpeta `ServidorSockets`
> (la que contiene la carpeta `src`).

```
cd ServidorSockets
```

### 1. Compilar (una sola vez)

```
javac -encoding UTF-8 src/ServidorChat.java src/ClienteChat.java
```

Si no aparece ningún mensaje, la compilación fue correcta. Los archivos `.class` quedan dentro de `src`.

### 2. Iniciar el servidor

```
java -cp src ServidorChat
```

Debe aparecer: `Servidor escuchando en el puerto 5000...`
La terminal queda ocupada mientras el servidor esté encendido. Para detenerlo: **Ctrl + C**.

Para usar otro puerto, se indica como argumento:

```
java -cp src ServidorChat 6000
```

### 3. Conectar clientes para probarlo

El servidor funciona con cualquier cliente que respete el protocolo. Con el cliente incluido,
en una terminal nueva por cada cliente (también desde la carpeta `ServidorSockets`):

```
java -cp src ClienteChat
```

El cliente pregunta la IP (Enter = `localhost`), el puerto (Enter = `5000`) y el nombre de usuario.
Si el servidor está en otro equipo, se escribe su IP, o se pasa como argumento:

```
java -cp src ClienteChat 192.168.1.20 5000
```

## Protocolo de mensajes

| Dirección | Contenido |
|---|---|
| Cliente → servidor (primera línea) | nombre de usuario |
| Cliente → servidor | `@destinatario mensaje` (ej. `@ana hola, ¿ya terminaste?`) |
| Cliente → servidor | `/salir` |
| Servidor → destinatario | `remitente (privado): mensaje` |
| Servidor → remitente | avisos: destinatario inexistente, formato inválido, nombre repetido |

Cada mensaje es una línea de texto terminada en salto de línea, en codificación UTF-8.

## Cómo funciona el servidor

| Requisito | Cómo se cumple |
|---|---|
| Varios clientes a la vez | El hilo principal solo ejecuta `accept()`; por cada conexión crea un hilo nuevo que atiende a ese cliente. Un cliente lento o bloqueado no afecta a los demás. |
| Nombre de usuario único | La primera línea es el nombre. Si está vacío, tiene espacios, empieza con `@` o `/`, o ya está en uso, se responde con un error y se cierra esa conexión. La comprobación y el registro se hacen juntos dentro de un bloque `synchronized`, para que dos clientes no tomen el mismo nombre a la vez. |
| Lista de usuarios conectados | Un mapa `nombre -> flujo de salida`. La lista se muestra en la consola del servidor cada vez que alguien entra o sale, y se envía al cliente al conectarse. |
| Mensajes privados | Se busca al destinatario en el mapa y solo a él se le envía `remitente (privado): mensaje`. |
| Destinatario inexistente | Se avisa al remitente: `El usuario 'x' no existe o no esta conectado.` |
| Desconexión | Con `/salir`, con cierre sin avisar o con un error de red, el hilo del cliente lo retira del mapa en un bloque `finally` y cierra su socket. El servidor sigue funcionando para los demás. |

## Prueba de funcionamiento

La carpeta `capturas/` muestra una prueba con 3 clientes conectados al mismo tiempo (`ana`, `beto` y `carlos`):

| Archivo | Qué muestra |
|---|---|
| `01_servidor.png` | Registro del servidor durante toda la prueba |
| `02_cliente_ana.png`, `03_cliente_beto.png`, `04_cliente_carlos.png` | **Mensaje privado entregado** a su destinatario (ana ↔ beto, carlos → ana) y **mensaje a un usuario inexistente** (`@luis`) |
| `04_cliente_carlos.png` y `01_servidor.png` | **Desconexión de un cliente** con `/salir` (carlos) |
| `03_cliente_beto.png` y `01_servidor.png` | **Cierre inesperado** (beto se cierra sin `/salir`); el servidor lo retira y sigue |
| `05_nombre_repetido.png` | Un nombre repetido (`ana`) es rechazado |
| `06_cliente_diana.png` | Después de las desconexiones, el servidor sigue aceptando clientes nuevos |

## Cambios respecto al servidor de clase

El servidor visto en clase tenía fallos que impedían que los mensajes llegaran. Se corrigió y se amplió:

1. Se usaba `print()` en lugar de `println()`: sin salto de línea ni vaciado del búfer, los clientes (que leen con `readLine()`) nunca recibían nada.
2. Con un nombre repetido, el bloque `finally` eliminaba al usuario que **sí** estaba conectado con ese nombre. Ahora solo se retira a quien logró registrarse.
3. Solo aceptaba `salir`; ahora acepta `/salir`, como pide el protocolo (`salir` se sigue aceptando por compatibilidad).
4. El mensaje de bienvenida se imprimía en la consola del servidor; ahora se envía al cliente.
5. Se agregó la validación del nombre, el acceso sincronizado a la lista de usuarios, el aviso al remitente si la entrega falla y el puerto como argumento opcional.

## Problemas frecuentes

| Mensaje o síntoma | Causa y solución |
|---|---|
| `error: file not found: src\ServidorChat.java` | La terminal no está en la carpeta `ServidorSockets`. Usar `cd` hasta la carpeta que contiene `src`. |
| `javac` no se reconoce como comando | El JDK no está instalado o no está en el PATH. |
| `Could not find or load main class` | Falta compilar, la terminal no está en `ServidorSockets` o falta `-cp src`. |
| `No se pudo iniciar el servidor... Address already in use` | Ya hay otro servidor en ese puerto. Cerrarlo, o usar otro: `java -cp src ServidorChat 6000`. |
| El cliente dice `Servidor no disponible` | El servidor no está encendido, o el puerto o la IP no coinciden. |
| Los acentos o la `¿` se ven mal en Windows | Ejecutar antes `chcp 65001`, o usar `java -Dstdout.encoding=UTF-8 -cp src ServidorChat`. |
